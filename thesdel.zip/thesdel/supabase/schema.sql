-- Supabase SQL Schema for Thesdel App

-- Enable UUID generation
create extension if not exists "uuid-ossp";

-- PROFILES TABLE
create table if not exists public.profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  name text not null,
  email text not null unique,
  role text not null default 'member' check (role in ('member', 'assistant', 'representative', 'admin', 'investor')),
  phone text,
  plan text not null default 'free' check (plan in ('free', 'basic', 'premium')),
  whatsapp_number text,
  is_reminder_number_locked boolean not null default false,
  status text not null default 'active' check (status in ('active', 'suspended', 'banned', 'deleted')),
  status_reason text,
  status_expiry timestamp with time zone,
  admin_level text check (admin_level in ('super_admin', 'junior_admin', 'minor_admin')),
  can_create_admins boolean default false,
  investor_expires_at timestamp with time zone,
  created_at timestamp with time zone default now()
);

-- Enable RLS for profiles
alter table public.profiles enable row level security;

-- CLASSES TABLE
create table if not exists public.classes (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  code text not null unique,
  owner_id uuid references public.profiles(id) on delete cascade not null,
  description text,
  visibility text not null default 'public' check (visibility in ('public', 'private')),
  created_at timestamp with time zone default now()
);

-- Enable RLS for classes
alter table public.classes enable row level security;

-- CLASS MEMBERS TABLE
create table if not exists public.class_members (
  id uuid default gen_random_uuid() primary key,
  class_id uuid references public.classes(id) on delete cascade not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  role text not null default 'member' check (role in ('member', 'assistant')),
  status text not null default 'approved' check (status in ('approved', 'pending', 'rejected')),
  created_at timestamp with time zone default now(),
  unique(class_id, user_id)
);

-- Enable RLS for class_members
alter table public.class_members enable row level security;

-- TIMETABLE TABLE
create table if not exists public.timetable (
  id uuid default gen_random_uuid() primary key,
  class_id uuid references public.classes(id) on delete cascade not null,
  subject text not null,
  day_of_week integer not null check (day_of_week between 1 and 7),
  start_time text not null, -- "HH:MM"
  end_time text not null, -- "HH:MM"
  duration_minutes integer not null,
  venue text not null,
  original_venue text,
  venue_changed_at timestamp with time zone,
  is_cancelled boolean not null default false,
  cancelled_at timestamp with time zone,
  created_at timestamp with time zone default now()
);

-- Enable RLS for timetable
alter table public.timetable enable row level security;

-- ATTENDANCE LOGS TABLE
create table if not exists public.attendance_logs (
  id uuid default gen_random_uuid() primary key,
  class_id uuid references public.classes(id) on delete cascade not null,
  timetable_entry_id uuid references public.timetable(id) on delete cascade not null,
  date text not null, -- "YYYY-MM-DD"
  status text not null check (status in ('attended', 'missed')),
  user_id uuid references public.profiles(id) on delete cascade not null,
  timestamp timestamp with time zone default now(),
  unique(timetable_entry_id, date, user_id)
);

-- Enable RLS for attendance_logs
alter table public.attendance_logs enable row level security;

-- UPDATES / ANNOUNCEMENTS TABLE
create table if not exists public.updates (
  id uuid default gen_random_uuid() primary key,
  class_id uuid references public.classes(id) on delete cascade not null,
  user_id uuid references public.profiles(id) on delete set null,
  user_name text not null,
  type text not null check (type in ('venue_change', 'cancellation', 'entry_added', 'entry_edited', 'entry_deleted')),
  description text not null,
  timestamp timestamp with time zone default now()
);

-- Enable RLS for updates
alter table public.updates enable row level security;


-- ==========================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ==========================================

-- PROFILES Policies
create policy "Profiles are viewable by authenticated users"
  on public.profiles for select
  to authenticated
  using (true);

create policy "Users can update their own profile"
  on public.profiles for update
  to authenticated
  using (auth.uid() = id);

create policy "Users can insert their own profile"
  on public.profiles for insert
  to authenticated
  with check (auth.uid() = id);

-- CLASSES Policies
create policy "Classes are viewable by all authenticated users"
  on public.classes for select
  to authenticated
  using (true);

create policy "Authenticated users can create classes"
  on public.classes for insert
  to authenticated
  with check (owner_id = auth.uid());

create policy "Only class owners can update classes"
  on public.classes for update
  to authenticated
  using (owner_id = auth.uid());

create policy "Only class owners can delete classes"
  on public.classes for delete
  to authenticated
  using (owner_id = auth.uid());

-- CLASS_MEMBERS Policies
create policy "Members list viewable by class members"
  on public.class_members for select
  to authenticated
  using (
    exists (
      select 1 from public.classes
      where id = class_id and (owner_id = auth.uid() or exists (
        select 1 from public.class_members cm where cm.class_id = id and cm.user_id = auth.uid()
      ))
    )
  );

create policy "Users can join classes as a member"
  on public.class_members for insert
  to authenticated
  with check (user_id = auth.uid() and role = 'member');

create policy "Only class owners can update memberships"
  on public.class_members for update
  to authenticated
  using (
    exists (
      select 1 from public.classes
      where id = class_id and owner_id = auth.uid()
    )
  );

create policy "Users can leave classes or owners can remove members"
  on public.class_members for delete
  to authenticated
  using (
    user_id = auth.uid() OR
    exists (
      select 1 from public.classes
      where id = class_id and owner_id = auth.uid()
    )
  );

-- TIMETABLE Policies
create policy "Timetable entries viewable by class members and owner"
  on public.timetable for select
  to authenticated
  using (
    exists (
      select 1 from public.classes
      where id = class_id and (owner_id = auth.uid() or exists (
        select 1 from public.class_members cm where cm.class_id = id and cm.user_id = auth.uid()
      ))
    )
  );

create policy "Timetable modifications by representative"
  on public.timetable for all
  to authenticated
  using (
    exists (
      select 1 from public.classes
      where id = class_id and owner_id = auth.uid()
    ) OR
    exists (
      select 1 from public.class_members
      where class_id = class_id and user_id = auth.uid() and role = 'assistant'
    )
  );

-- ATTENDANCE_LOGS Policies
create policy "Users can view their own attendance logs"
  on public.attendance_logs for select
  to authenticated
  using (user_id = auth.uid());

create policy "Users can log their own attendance if in class"
  on public.attendance_logs for insert
  to authenticated
  with check (
    user_id = auth.uid() AND
    (
      exists (
        select 1 from public.classes
        where id = class_id and owner_id = auth.uid()
      ) OR
      exists (
        select 1 from public.class_members
        where class_id = class_id and user_id = auth.uid()
      )
    )
  );

create policy "Users can modify their own attendance logs"
  on public.attendance_logs for update
  to authenticated
  using (user_id = auth.uid());

create policy "Users can delete their own attendance logs"
  on public.attendance_logs for delete
  to authenticated
  using (user_id = auth.uid());

-- UPDATES Policies
create policy "Class updates viewable by members and owner"
  on public.updates for select
  to authenticated
  using (
    exists (
      select 1 from public.classes
      where id = class_id and (owner_id = auth.uid() or exists (
        select 1 from public.class_members cm where cm.class_id = id and cm.user_id = auth.uid()
      ))
    )
  );

create policy "Updates posted by representative or assistant"
  on public.updates for insert
  to authenticated
  with check (
    user_id = auth.uid() AND (
      exists (
        select 1 from public.classes
        where id = class_id and owner_id = auth.uid()
      ) OR
      exists (
        select 1 from public.class_members
        where class_id = class_id and user_id = auth.uid() and role = 'assistant'
      )
    )
  );


-- ==========================================
-- AUTOMATION TRIGGERS & FUNCTIONS
-- ==========================================

-- Trigger to copy newly registered auth.users into profiles automatically
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, name, email, role, phone, plan)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)),
    new.email,
    coalesce(new.raw_user_meta_data->>'role', 'member'),
    coalesce(new.raw_user_meta_data->>'phone', ''),
    'free'
  );
  return new;
end;
$$ language plpgsql security definer;

create or replace trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Trigger to prevent regular users from changing crucial profile fields
create or replace function public.check_profile_updates()
returns trigger as $$
begin
  -- Regular users cannot change their own role, plan, or locked state from the client
  if (OLD.role <> NEW.role) then
    raise exception 'Changing role directly is forbidden.';
  end if;
  if (OLD.plan <> NEW.plan) then
    raise exception 'Changing subscription plan directly is forbidden.';
  end if;
  if (OLD.is_reminder_number_locked <> NEW.is_reminder_number_locked) then
    raise exception 'Changing reminder lock status is forbidden.';
  end if;
  if (OLD.is_reminder_number_locked = true and OLD.whatsapp_number <> NEW.whatsapp_number) then
    raise exception 'Locked WhatsApp reminder number cannot be updated.';
  end if;
  return NEW;
end;
$$ language plpgsql security definer;

create or replace trigger enforce_profile_limits
  before update on public.profiles
  for each row execute procedure public.check_profile_updates();


-- PENDING REMOVALS TABLE
create table if not exists public.pending_removals (
  id uuid default gen_random_uuid() primary key,
  class_id uuid references public.classes(id) on delete cascade not null,
  user_id uuid references public.profiles(id) on delete cascade not null,
  requested_by uuid references public.profiles(id) on delete cascade not null,
  created_at timestamp with time zone default now(),
  unique(class_id, user_id)
);

-- Enable RLS for pending_removals
alter table public.pending_removals enable row level security;

-- PENDING REMOVALS Policies
create policy "Pending removals are viewable by class members"
  on public.pending_removals for select
  to authenticated
  using (
    exists (
      select 1 from public.classes
      where id = class_id and (owner_id = auth.uid() or exists (
        select 1 from public.class_members cm where cm.class_id = id and cm.user_id = auth.uid()
      ))
    )
  );

create policy "Assistants can request member removal"
  on public.pending_removals for insert
  to authenticated
  with check (
    exists (
      select 1 from public.class_members
      where class_id = class_id and user_id = auth.uid() and role = 'assistant'
    )
  );

create policy "Only class owners can manage pending removals"
  on public.pending_removals for delete
  to authenticated
  using (
    exists (
      select 1 from public.classes
      where id = class_id and owner_id = auth.uid()
    )
  );


-- ==========================================
-- SUBSCRIPTION PRICING TABLE (USD BASE)
-- ==========================================

create table if not exists public.subscription_prices (
  plan text primary key check (plan in ('basic', 'premium')),
  price_usd numeric(10,2) not null,
  updated_at timestamp with time zone default now()
);

-- Enable RLS
alter table public.subscription_prices enable row level security;

-- Insert default prices if not exists
insert into public.subscription_prices (plan, price_usd)
values 
  ('basic', 1.00),
  ('premium', 3.00)
on conflict (plan) do nothing;

-- Pricing select policy (anyone can read the prices)
create policy "Prices are viewable by everyone"
  on public.subscription_prices for select
  to authenticated, anon
  using (true);


-- =========================================================================
-- THE_SDEL WORKSPACE ADMIN SYSTEM SCHEMA (AUDIT, MODERATION & INVESTORS)
-- =========================================================================

-- 1. EXTEND ROLES AND ADD STATUS TO PROFILES
DO $$
BEGIN
  -- Alter role check constraint on public.profiles
  ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_role_check;
EXCEPTION
  WHEN others THEN NULL;
END $$;

ALTER TABLE public.profiles ADD CONSTRAINT profiles_role_check CHECK (role IN ('member', 'assistant', 'representative', 'admin', 'investor'));

-- Add status columns to profiles if they don't exist
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'banned', 'deleted'));
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS status_reason text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS status_expiry timestamp with time zone;

-- 2. HELPER SECURITY FUNCTIONS (SECURITY DEFINER)
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin' AND status = 'active'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.is_investor()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'investor' AND status = 'active'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.is_user_active(user_id uuid)
RETURNS boolean AS $$
DECLARE
  v_status text;
  v_expiry timestamp with time zone;
BEGIN
  SELECT status, status_expiry INTO v_status, v_expiry
  FROM public.profiles
  WHERE id = user_id;
  
  IF v_status IS NULL THEN
    RETURN true; -- Safe fallback for new profiles creation
  END IF;
  
  IF v_status = 'active' then
    RETURN true;
  ELSIF v_status = 'suspended' then
    IF v_expiry IS NOT NULL AND v_expiry < now() THEN
      -- Suspension expired, auto-restore
      UPDATE public.profiles 
      SET status = 'active', status_reason = NULL, status_expiry = NULL 
      WHERE id = user_id;
      RETURN true;
    ELSE
      RETURN false;
    END IF;
  ELSE
    RETURN false; -- banned or deleted
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 3. ADMIN AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS public.admin_audit_logs (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  admin_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  admin_email text NOT NULL,
  action text NOT NULL, -- 'login', 'moderation', 'investor_invite', 'permission_change', 'export', 'suspend_user', 'ban_user', 'restore_user'
  target_user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  details jsonb DEFAULT '{}'::jsonb,
  created_at timestamp with time zone DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.admin_audit_logs ENABLE ROW LEVEL SECURITY;

-- Read-only policy for admins
CREATE POLICY "Admins can view all audit logs"
  ON public.admin_audit_logs FOR SELECT
  TO authenticated
  USING (public.is_admin());

-- Insert policy for admins
CREATE POLICY "Admins can create audit logs"
  ON public.admin_audit_logs FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

-- Deny updates/deletes completely (immutable logs)
CREATE POLICY "Audit logs are immutable"
  ON public.admin_audit_logs FOR UPDATE
  TO authenticated
  USING (false);

CREATE POLICY "Audit logs cannot be deleted"
  ON public.admin_audit_logs FOR DELETE
  TO authenticated
  USING (false);


-- 4. INVESTOR INVITATIONS TABLE
CREATE TABLE IF NOT EXISTS public.investor_invitations (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  email text NOT NULL UNIQUE,
  invited_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'revoked')),
  token text NOT NULL UNIQUE,
  created_at timestamp with time zone DEFAULT now(),
  expires_at timestamp with time zone NOT NULL
);

-- Enable RLS
ALTER TABLE public.investor_invitations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage investor invitations"
  ON public.investor_invitations FOR ALL
  TO authenticated
  USING (public.is_admin());

CREATE POLICY "Public can view active invitations to sign up"
  ON public.investor_invitations FOR SELECT
  TO anon, authenticated
  USING (status = 'pending' AND expires_at > now());


-- 5. SUBSCRIPTION TRANSACTIONS TABLE
CREATE TABLE IF NOT EXISTS public.subscription_transactions (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  reference text NOT NULL UNIQUE,
  amount numeric(10, 2) NOT NULL,
  currency text NOT NULL DEFAULT 'NGN',
  status text NOT NULL CHECK (status IN ('success', 'failed', 'refunded', 'cancelled')),
  tier text NOT NULL CHECK (tier IN ('free', 'basic', 'premium')),
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.subscription_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage transactions"
  ON public.subscription_transactions FOR ALL
  TO authenticated
  USING (public.is_admin());

CREATE POLICY "Users can view their own transactions"
  ON public.subscription_transactions FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());


-- 6. PRIVACY-SAFE ANALYTICS EVENTS TABLE
CREATE TABLE IF NOT EXISTS public.analytics_events (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  anonymous_id text NOT NULL,
  event_type text NOT NULL, -- 'session_start', 'click', 'screen_usage', 'time_spent', 'tab_view'
  screen_name text,
  details jsonb DEFAULT '{}'::jsonb,
  timestamp timestamp with time zone DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.analytics_events ENABLE ROW LEVEL SECURITY;

-- Admins can view raw events
CREATE POLICY "Admins can view raw analytics"
  ON public.analytics_events FOR SELECT
  TO authenticated
  USING (public.is_admin());

-- Anyone can write analytics events
CREATE POLICY "Anyone can write analytics"
  ON public.analytics_events FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);


-- 7. ANONYMOUS AGGREGATE INVESTOR ANALYTICS RPC
-- Enforce minimum threshold of 10 users to protect privacy
CREATE OR REPLACE FUNCTION public.get_investor_analytics()
RETURNS jsonb AS $$
DECLARE
  v_user_count bigint;
  v_result jsonb;
  v_is_authorized boolean;
BEGIN
  -- Check if caller is Admin or Investor
  v_is_authorized := public.is_admin() OR public.is_investor();
  IF NOT v_is_authorized THEN
    RAISE EXCEPTION 'Permission Denied: Unauthorized access to investor analytics';
  END IF;

  -- Check distinct user threshold in profiles
  SELECT COUNT(DISTINCT id) INTO v_user_count FROM public.profiles;

  IF v_user_count < 10 THEN
    -- Return blank aggregates when threshold is not met to protect privacy
    RETURN jsonb_build_object(
      'threshold_met', false,
      'message', 'Metrics hidden. Minimum aggregation threshold of 10 distinct users is required.',
      'total_signups', 0,
      'dau', 0,
      'wau', 0,
      'mau', 0,
      'mrr', 0.00,
      'revenue_summary', '[]'::jsonb
    );
  END IF;

  -- Build secure aggregates
  SELECT jsonb_build_object(
    'threshold_met', true,
    'total_signups', (SELECT COUNT(*) FROM public.profiles),
    'dau', (
      -- Distinct active anonymous IDs in the last 24 hours
      SELECT COUNT(DISTINCT anonymous_id) 
      FROM public.analytics_events 
      WHERE timestamp >= now() - interval '1 day'
    ),
    'wau', (
      -- Distinct active anonymous IDs in the last 7 days
      SELECT COUNT(DISTINCT anonymous_id) 
      FROM public.analytics_events 
      WHERE timestamp >= now() - interval '7 days'
    ),
    'mau', (
      -- Distinct active anonymous IDs in the last 30 days
      SELECT COUNT(DISTINCT anonymous_id) 
      FROM public.analytics_events 
      WHERE timestamp >= now() - interval '30 days'
    ),
    'mrr', (
      -- Sum basic ($1) and premium ($3) plans
      SELECT COALESCE(SUM(
        CASE 
          WHEN plan = 'basic' THEN 1.00
          WHEN plan = 'premium' THEN 3.00
          ELSE 0.00
        END
      ), 0.00)
      FROM public.profiles
    ),
    'revenue_by_tier', (
      SELECT jsonb_object_agg(tier, COALESCE(SUM(amount), 0.00))
      FROM public.subscription_transactions
      WHERE status = 'success'
    ),
    'transactions_summary', (
      SELECT jsonb_build_object(
        'success', COUNT(*) FILTER (WHERE status = 'success'),
        'failed', COUNT(*) FILTER (WHERE status = 'failed'),
        'refunded', COUNT(*) FILTER (WHERE status = 'refunded'),
        'cancelled', COUNT(*) FILTER (WHERE status = 'cancelled')
      )
      FROM public.subscription_transactions
    )
  ) INTO v_result;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- 8. INTEGRATE ACCOUNT BLOCKS INTO EXISTING RLS
-- To protect classes and logs from suspended or banned accounts, we can restrict SELECT/UPDATE/INSERT
-- based on public.is_user_active(auth.uid())

CREATE OR REPLACE FUNCTION public.check_user_active_trigger()
RETURNS trigger AS $$
BEGIN
  IF NOT public.is_user_active(auth.uid()) THEN
    RAISE EXCEPTION 'Access Denied: Your account is suspended, banned, or deleted.';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- 9. AD ANALYTICS TABLE
CREATE TABLE IF NOT EXISTS public.ad_analytics (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  ad_id uuid REFERENCES public.updates(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  event_type text NOT NULL CHECK (event_type IN ('view', 'click')),
  created_at timestamp with time zone DEFAULT now()
);

-- Enable RLS for ad_analytics
ALTER TABLE public.ad_analytics ENABLE ROW LEVEL SECURITY;

-- ad_analytics Policies
CREATE POLICY "Users can log their own ad events"
  ON public.ad_analytics FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can view ad analytics"
  ON public.ad_analytics FOR SELECT
  TO authenticated
  USING (public.is_admin());




