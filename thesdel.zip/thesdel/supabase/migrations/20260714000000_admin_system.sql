-- Migration: Admin System Schema, Moderation, Audit Logs, and Investor Access
-- Created: 2026-07-14

-- 1. EXTEND ROLES AND ADD STATUS TO PROFILES
DO $$
BEGIN
  -- Alter role check constraint on public.profiles
  ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_role_check;
EXCEPTION
  WHEN others THEN NULL;
END $$;

ALTER TABLE public.profiles ADD CONSTRAINT profiles_role_check CHECK (role IN ('member', 'assistant', 'representative', 'admin', 'investor'));

-- Add status columns to profiles if they don't exist
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'banned', 'deleted'));
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS status_reason text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS status_expiry timestamp with time zone;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS admin_level text CHECK (admin_level IN ('super_admin', 'junior_admin', 'minor_admin'));
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS can_create_admins boolean DEFAULT false;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS investor_expires_at timestamp with time zone;

-- 2. HELPER SECURITY FUNCTIONS (SECURITY DEFINER)
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin' AND status = 'active'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.is_investor()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'investor' AND status = 'active'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.is_user_active(user_id uuid)
RETURNS boolean AS $$
DECLARE
  v_status text;
  v_expiry timestamp with time zone;
BEGIN
  SELECT status, status_expiry INTO v_status, v_expiry
  FROM public.profiles
  WHERE id = user_id;
  
  IF v_status IS NULL THEN
    RETURN true; -- Safe fallback for new profiles creation
  END IF;
  
  IF v_status = 'active' then
    RETURN true;
  ELSIF v_status = 'suspended' then
    IF v_expiry IS NOT NULL AND v_expiry < now() THEN
      -- Suspension expired, auto-restore
      UPDATE public.profiles 
      SET status = 'active', status_reason = NULL, status_expiry = NULL 
      WHERE id = user_id;
      RETURN true;
    ELSE
      RETURN false;
    END IF;
  ELSE
    RETURN false; -- banned or deleted
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 3. ADMIN AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS public.admin_audit_logs (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  admin_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  admin_email text NOT NULL,
  action text NOT NULL, -- 'login', 'moderation', 'investor_invite', 'permission_change', 'export', 'suspend_user', 'ban_user', 'restore_user'
  target_user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  details jsonb DEFAULT '{}'::jsonb,
  created_at timestamp with time zone DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.admin_audit_logs ENABLE ROW LEVEL SECURITY;

-- Read-only policy for admins
CREATE POLICY "Admins can view all audit logs"
  ON public.admin_audit_logs FOR SELECT
  TO authenticated
  USING (public.is_admin());

-- Insert policy for admins
CREATE POLICY "Admins can create audit logs"
  ON public.admin_audit_logs FOR INSERT
  TO authenticated
  WITH CHECK (public.is_admin());

-- Deny updates/deletes completely (immutable logs)
CREATE POLICY "Audit logs are immutable"
  ON public.admin_audit_logs FOR UPDATE
  TO authenticated
  USING (false);

CREATE POLICY "Audit logs cannot be deleted"
  ON public.admin_audit_logs FOR DELETE
  TO authenticated
  USING (false);


-- 4. INVESTOR INVITATIONS TABLE
CREATE TABLE IF NOT EXISTS public.investor_invitations (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  email text NOT NULL UNIQUE,
  invited_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'revoked')),
  token text NOT NULL UNIQUE,
  created_at timestamp with time zone DEFAULT now(),
  expires_at timestamp with time zone NOT NULL
);

-- Enable RLS
ALTER TABLE public.investor_invitations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage investor invitations"
  ON public.investor_invitations FOR ALL
  TO authenticated
  USING (public.is_admin());

CREATE POLICY "Public can view active invitations to sign up"
  ON public.investor_invitations FOR SELECT
  TO anon, authenticated
  USING (status = 'pending' AND expires_at > now());


-- 5. SUBSCRIPTION TRANSACTIONS TABLE
CREATE TABLE IF NOT EXISTS public.subscription_transactions (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  reference text NOT NULL UNIQUE,
  amount numeric(10, 2) NOT NULL,
  currency text NOT NULL DEFAULT 'NGN',
  status text NOT NULL CHECK (status IN ('success', 'failed', 'refunded', 'cancelled')),
  tier text NOT NULL CHECK (tier IN ('free', 'basic', 'premium')),
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.subscription_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage transactions"
  ON public.subscription_transactions FOR ALL
  TO authenticated
  USING (public.is_admin());

CREATE POLICY "Users can view their own transactions"
  ON public.subscription_transactions FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());


-- 6. PRIVACY-SAFE ANALYTICS EVENTS TABLE
CREATE TABLE IF NOT EXISTS public.analytics_events (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  anonymous_id text NOT NULL,
  event_type text NOT NULL, -- 'session_start', 'click', 'screen_usage', 'time_spent', 'tab_view'
  screen_name text,
  details jsonb DEFAULT '{}'::jsonb,
  timestamp timestamp with time zone DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.analytics_events ENABLE ROW LEVEL SECURITY;

-- Admins can view raw events
CREATE POLICY "Admins can view raw analytics"
  ON public.analytics_events FOR SELECT
  TO authenticated
  USING (public.is_admin());

-- Anyone can write analytics events
CREATE POLICY "Anyone can write analytics"
  ON public.analytics_events FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);


-- 7. ANONYMOUS AGGREGATE INVESTOR ANALYTICS RPC
-- Enforce minimum threshold of 10 users to protect privacy
CREATE OR REPLACE FUNCTION public.get_investor_analytics()
RETURNS jsonb AS $$
DECLARE
  v_user_count bigint;
  v_result jsonb;
  v_is_authorized boolean;
BEGIN
  -- Check if caller is Admin or Investor
  v_is_authorized := public.is_admin() OR public.is_investor();
  IF NOT v_is_authorized THEN
    RAISE EXCEPTION 'Permission Denied: Unauthorized access to investor analytics';
  END IF;

  -- Check distinct user threshold in profiles
  SELECT COUNT(DISTINCT id) INTO v_user_count FROM public.profiles;

  IF v_user_count < 10 THEN
    -- Return blank aggregates when threshold is not met to protect privacy
    RETURN jsonb_build_object(
      'threshold_met', false,
      'message', 'Metrics hidden. Minimum aggregation threshold of 10 distinct users is required.',
      'total_signups', 0,
      'dau', 0,
      'wau', 0,
      'mau', 0,
      'mrr', 0.00,
      'revenue_summary', '[]'::jsonb
    );
  END IF;

  -- Build secure aggregates
  SELECT jsonb_build_object(
    'threshold_met', true,
    'total_signups', (SELECT COUNT(*) FROM public.profiles),
    'dau', (
      -- Distinct active anonymous IDs in the last 24 hours
      SELECT COUNT(DISTINCT anonymous_id) 
      FROM public.analytics_events 
      WHERE timestamp >= now() - interval '1 day'
    ),
    'wau', (
      -- Distinct active anonymous IDs in the last 7 days
      SELECT COUNT(DISTINCT anonymous_id) 
      FROM public.analytics_events 
      WHERE timestamp >= now() - interval '7 days'
    ),
    'mau', (
      -- Distinct active anonymous IDs in the last 30 days
      SELECT COUNT(DISTINCT anonymous_id) 
      FROM public.analytics_events 
      WHERE timestamp >= now() - interval '30 days'
    ),
    'mrr', (
      -- Sum basic ($1) and premium ($3) plans
      SELECT COALESCE(SUM(
        CASE 
          WHEN plan = 'basic' THEN 1.00
          WHEN plan = 'premium' THEN 3.00
          ELSE 0.00
        END
      ), 0.00)
      FROM public.profiles
    ),
    'revenue_by_tier', (
      SELECT jsonb_object_agg(tier, COALESCE(SUM(amount), 0.00))
      FROM public.subscription_transactions
      WHERE status = 'success'
    ),
    'transactions_summary', (
      SELECT jsonb_build_object(
        'success', COUNT(*) FILTER (WHERE status = 'success'),
        'failed', COUNT(*) FILTER (WHERE status = 'failed'),
        'refunded', COUNT(*) FILTER (WHERE status = 'refunded'),
        'cancelled', COUNT(*) FILTER (WHERE status = 'cancelled')
      )
      FROM public.subscription_transactions
    )
  ) INTO v_result;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- 8. INTEGRATE ACCOUNT BLOCKS INTO EXISTING RLS
-- To protect classes and logs from suspended or banned accounts, we can restrict SELECT/UPDATE/INSERT
-- based on public.is_user_active(auth.uid())

CREATE OR REPLACE FUNCTION public.check_user_active_trigger()
RETURNS trigger AS $$
BEGIN
  IF NOT public.is_user_active(auth.uid()) THEN
    RAISE EXCEPTION 'Access Denied: Your account is suspended, banned, or deleted.';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
