# Thesdel Application Pages Directory Map

Use this document to locate pages, tabs, modals, and workflows in the Thesdel codebase. This serves as a structural map for developers and AI assistants to quickly find files for debugging and enhancements.

---

## 1. Authentication & Initial Screens
These files manage the user onboarding, account login, registration, and initial landing page.

* **Landing / Login / Signup / Recovery Screens:**
  * **File:** `/src/components/LandingView.tsx`
  * **Description:** The entry screen shown to unauthenticated users. Contains the landing overview, modern login form, secret key recovery form (Forgot Password flow utilizing Supabase resetPasswordForEmail), custom registration input fields (Name, Email, Phone, Password, Role picker), and Terms / Privacy policies.
  * **Debugging Focus:** Authentication state, custom user registration metadata triggers, email/password validation, password recovery dispatch, and signup errors.

---

## 2. Student Portal Views (Core Tabs)
The main student application uses a SPA architecture driven by state management (`currentView`). The root coordinator file that manages active views, offline queue checks, and header/footer layouts is:
* **Root Coordinator:** `/src/App.tsx`

| Portal Tab | File Path | Description / Key UI Features |
| :--- | :--- | :--- |
| **Today (Home)** | `/src/components/HomeView.tsx` | Dashboard showing the classes scheduled for the current day. Includes checking/marking attendance, posting Representative broadcasts, displaying school announcements, and showing tracked ad campaigns. |
| **Timetable** | `/src/components/TimetableView.tsx` | Weekly grid of scheduled classes. Representatives/Assistants can add, edit, or delete classes, change venues, and trigger streak-safe class cancellations. |
| **Attendance** | `/src/components/AttendanceView.tsx` | Analytics dashboard tracking attendance rates, active streaks, attendance calendars, and downloadable log tables. |
| **Class** | `/src/components/ClassView.tsx` | Classroom manager. Allows users to create new class codes (public/private), search/join classes with codes, manage members (promote/demote roles), and review member removal requests. |
| **Profile** | `/src/components/ProfileView.tsx` | Profile identity card view with student badge, enrolled classes overview, and account logging mechanisms. Includes the logout option. |
| **Settings** | `/src/components/SettingsView.tsx` | Settings configuration screen for changing names/phones, linking WhatsApp reminder numbers, locking phone reminders, and modifying general preferences. |
| **Notifications** | `/src/components/NotificationsView.tsx` | Consolidated feed of all school updates, room change logs, and class cancellations with manual sync controls. |

### Supporting UI Component Sub-modules:
* **WhatsApp Country Picker:** `/src/components/CountryCodeSelector.tsx`
* **Notification Reminders Form:** `/src/components/ReminderSettingsView.tsx`

---

## 3. Administrative & Investor Console
A fully decoupled, secure console accessible by system administrators (`admin`) and lead venture partners (`investor`). 
* **Admin Router Coordinator:** `/admin/AdminApp.tsx`

| Admin View | File Path | Purpose & Included Widgets |
| :--- | :--- | :--- |
| **Console Dashboard** | `/admin/pages/Dashboard.tsx` | High-level metrics, active servers statuses, running process counters, and database load charts. |
| **User Manager** | `/admin/pages/Users.tsx` | Active database directory list. Admins can search user profiles, update subscriber plans, ban, or suspend accounts. |
| **Investors Hub** | `/admin/pages/Investors.tsx` | Capital allocation monitors, seed investor tables, and downloadable capital growth csv matrices. |
| **Revenue Monitor** | `/admin/pages/Revenue.tsx` | Payment gateway stream charts, active recurring subscriptions, invoice ledger, and financial status filters. |
| **Audit Logs** | `/admin/pages/AuditLogs.tsx` | Master security trail logging login attempts, data updates, and administrative overrides. |
| **Clickstream Matrix** | `/admin/pages/ClickstreamMatrix.tsx` | User navigation and action matrix. Captures click heatmaps and path flow records. |
| **Ads & Campaigns** | `/admin/pages/Ads.tsx` | Sponsored banner placement manager. Lets admins create campaigns and track click-through rates (CTR). |

---

## 4. Key Utilities & Libraries

* **Supabase Client SDK:** `/src/lib/supabase.ts` — Initializes connection credentials, state local caches (`localStorage`), and offline synchronization log queues.
* **Global State Store:** `/src/lib/store.ts` — Houses user view selections, theme states, active class selectors, and active sessions.
* **Analytical Telemetry Tracker:** `/src/utils/tracker.ts` — Hooks into clicks and views to send events to clickstream datasets.
* **Shared Types:** `/src/types.ts` — Defines interfaces for `User`, `ClassGroup`, `TimetableEntry`, `AttendanceLog`, and Roles.
* **Mock Backup Datasets:** `/src/src/mockData.ts` (or `/src/mockData.ts`) — Contains static fallbacks for offline simulation modes.
* **Global Styles:** `/src/index.css` — Configures custom typography (Inter, JetBrains Mono) and Tailwind presets.

---

## 5. Database Schema & Migration Setup
* **Main Schema definition:** `/supabase/schema.sql` (Tables, Triggers, RLS, functions)
* **Migrations folder:** `/supabase/migrations/20260714000000_admin_system.sql`
