# Guide to Deployment & Architecture

This guide is designed for developers, systems engineers, and database administrators to understand, configure, deploy, and manage the application. 

---

## 1. Core Architecture Overview

The application is built on a modern, high-performance stack:
* **Frontend Runtime:** React 18+ with Vite (TypeScript).
* **Styling:** Utility-first styling via Tailwind CSS.
* **Icons:** SVG vector iconography via `lucide-react`.
* **Database & Auth:** Supabase (PostgreSQL with Auth and Realtime).

### Key Directories & Files
* `/src/App.tsx` - Root coordinator. Handles route-dispatching, active session checks, Supabase auth state change listening, and page wrappers.
* `/src/lib/supabase.ts` - Supabase client initializer. Extracts environment variables safely and instantiates the client SDK.
* `/src/components/` - Sub-view components (e.g., `LandingView.tsx`, `ProfileView.tsx`, `HomeView.tsx`, `AttendanceView.tsx`).
* `/admin/` - Fully isolated, self-contained administrative and investor terminal dashboard module.
* `/supabase/schema.sql` - Complete PostgreSQL database schema definition including tables, triggers, policies, and foreign keys.

---

## 2. Database Setup & Supabase Connection

The application relies on Supabase for relational data storage, user authentication, and profile tracking.

### Step 1: Environment Variables
Create a `.env` file at your project's root folder (refer to `.env.example`). Provide your production Supabase credentials:
```env
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```
* **Note:** Vite requires public client-side variables to be prefixed with `VITE_` so they are bundled into the static build.

### Step 2: Apply the SQL Schema
1. Log in to your [Supabase Dashboard](https://supabase.com).
2. Open your project and navigate to the **SQL Editor** tab from the left sidebar.
3. Click **New Query**, copy the entire contents of `/supabase/schema.sql`, paste it into the editor, and click **Run**.
4. This script automatically handles:
   * Creation of the `profiles` table.
   * Setting up automated triggers that copy newly signed-up authenticated users from Supabase Auth (`auth.users`) straight into the public `profiles` table.
   * Activating Row-Level Security (RLS) policies to keep student/faculty data safe.

---

## 3. Row-Level Privileges & Administrative Setup (SQL)

All administrative authorization is handled securely at the database level using the `role` column in your `profiles` table. By default, new users sign up with the `'member'` role. 

**No client-side toggle or hidden simulator can assign a user the `'admin'` or `'investor'` role.** Role upgrades must be executed directly in your database.

### How to Make Yourself an Admin
To grant a specific user full system administrator rights, run the following SQL query inside the Supabase **SQL Editor**:

```sql
-- 1. Update the user's role to 'admin' using their Email address
UPDATE public.profiles
SET role = 'admin'
WHERE email = 'philipjonathanpeter24@gmail.com';

-- 2. Confirm the update was successful
SELECT id, email, role 
FROM public.profiles 
WHERE email = 'philipjonathanpeter24@gmail.com';
```

### How to Make Yourself a Lead Investor
To grant a specific user lead investor rights (allowing them to see financial records, revenue streams, and audits), execute this query:

```sql
-- 1. Update the user's role to 'investor' using their Email address
UPDATE public.profiles
SET role = 'investor'
WHERE email = 'your-investor-email@domain.com';

-- 2. Confirm the update was successful
SELECT id, email, role 
FROM public.profiles 
WHERE email = 'your-investor-email@domain.com';
```

---

## 4. Understanding & Troubleshooting the Profile Sync Flow

### How the Sign-Up/Login Sync Works:
1. When a user signs up on the frontend (`LandingView.tsx`), the application invokes `supabase.auth.signUp()`.
2. This creates an entry in Supabase's internal `auth.users` table.
3. The database trigger automatically creates a matching row inside the public `profiles` table with the user's name, phone, and role.
4. When a user logs in, the client queries `public.profiles` for a row matching the logged-in user's `auth.users.id`.

### Solving "Unable to load your profile. Please contact support"
If a user logs in successfully but sees this error dialog, it means **authenticated login was successful, but a matching profile row was not found in the public `profiles` table.**

**Troubleshooting Checklist for the Engineer:**
1. **Check SQL Trigger:** Verify that the trigger defined in `schema.sql` was successfully created. If not, the public `profiles` table will remain empty upon signup.
2. **Examine Console Logs:** We updated the code to log detailed diagnostics in the browser's developer console (F12). Look for:
   * `[LandingView] Profile select error:` (Check if the table name is correct, or if RLS is blocking reads).
   * `[LandingView] Profile insert error:` (Check if a column constraint is missing or failing, such as a null value on a required field).
3. **Verify Row-Level Security (RLS) Policies:** Ensure that authenticated users have permission to read their own rows. The policy should be:
   ```sql
   CREATE POLICY "Allow users to read their own profiles" 
   ON public.profiles 
   FOR SELECT 
   USING (auth.uid() = id);
   ```

### Debugging the "check_request() does not exist" Error
If your console logs or database responses show:
```json
{
  "code": "42883",
  "message": "function public.check_request() does not exist"
}
```
* **What this means:** Your `profiles` table has a leftover trigger, a check constraint, or an RLS policy from a previous database template/version that is trying to call a function named `check_request()`. Since this function doesn't exist, all database writes (signups/inserts) fail.
* **The Fix:** Run the following cleanup SQL query inside your Supabase **SQL Editor** to drop any outdated triggers, policies, and constraints, and then recreate the clean profile tables and policies:

```sql
-- 1. DROP CONFLICTING / OUTDATED TRIGGERS ON PROFILES
DROP TRIGGER IF EXISTS on_auth_user_created ON public.profiles CASCADE;
DROP TRIGGER IF EXISTS enforce_profile_limits ON public.profiles CASCADE;
DROP TRIGGER IF EXISTS check_request_trigger ON public.profiles CASCADE;

-- 2. DROP ALL OLD POLICIES TO PREVENT STALE RLS CALLS
DROP POLICY IF EXISTS "Profiles are viewable by authenticated users" ON public.profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert their own profile" ON public.profiles;

-- 3. RE-ESTABLISH ROW-LEVEL SECURITY
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Profiles are viewable by authenticated users"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile"
  ON public.profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- 4. RE-ESTABLISH THE CLEAN USER REGISTRATION AUTOMATION TRIGGER
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, name, email, role, phone, plan)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'role', 'member'),
    COALESCE(NEW.raw_user_meta_data->>'phone', ''),
    'free'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate the trigger on auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- 5. RE-ESTABLISH PROFILE UPDATE ENFORCEMENT LIMITS
CREATE OR REPLACE FUNCTION public.check_profile_updates()
RETURNS trigger AS $$
BEGIN
  IF (OLD.role <> NEW.role) THEN
    RAISE EXCEPTION 'Changing role directly is forbidden.';
  END IF;
  IF (OLD.plan <> NEW.plan) THEN
    RAISE EXCEPTION 'Changing subscription plan directly is forbidden.';
  END IF;
  IF (OLD.is_reminder_number_locked <> NEW.is_reminder_number_locked) THEN
    RAISE EXCEPTION 'Changing reminder lock status is forbidden.';
  END IF;
  IF (OLD.is_reminder_number_locked = true AND OLD.whatsapp_number <> NEW.whatsapp_number) THEN
    RAISE EXCEPTION 'Locked WhatsApp reminder number cannot be updated.';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER enforce_profile_limits
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE PROCEDURE public.check_profile_updates();
```

### Debugging SQL syntax error at or near "{" (import statements)
If you see this error:
`Failed to run sql query: ERROR: 42601: syntax error at or near "{" LINE 1: import { createClient } ...`
* **What this means:** You are attempting to run JavaScript/TypeScript code (such as React imports or API initializations) inside the Supabase **SQL Editor**. 
* **The Fix:** The SQL Editor only executes **PostgreSQL SQL commands** (like the tables, triggers, and policies listed above). Client-side TypeScript code belongs inside `/src/` files (e.g., `/src/lib/supabase.ts`) and is processed by the Vite compiler, not the database engine. Do not paste JavaScript/TypeScript inside the SQL Editor.

---

## 5. Production Build & Deployment Checklist

To go live tonight:

1. **Test Compilation Locally:**
   Run the following commands to confirm everything is pristine:
   ```bash
   # Install local package dependencies
   npm install
   
   # Run the TypeScript validator & linter
   npm run lint
   
   # Compile production static bundle
   npm run build
   ```
2. **Upload Build Artifacts:**
   The compiler places all production files into the `/dist` directory. This directory is entirely static and self-contained. You can deploy it to any hosting provider of your choice:
   * **Vercel / Netlify:** Import the repository, set the build command to `npm run build`, and configure output directory as `dist`. Add your two environment variables in their project settings UI.
   * **Supabase Hosting / Firebase Hosting / Cloud Run:** Configure deployment to serve static files from the build output directory (`dist/`).
3. **Configure Redirect URIs:**
   If you plan to use OAuth, password resets, or email verifications, make sure to add your live production domain (e.g., `https://yourdomain.com`) as an authorized Redirect URL under your **Supabase Dashboard -> Authentication -> URL Configuration**.
